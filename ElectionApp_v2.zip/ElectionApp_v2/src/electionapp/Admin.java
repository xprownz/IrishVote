/*

Admin.java 

Election App for Object Oriented Programming Project 
HCCE2&BHSC2 Class 2018-2019
By Cian Harris, Aaron Reilly and Alejandro Diaz
 */
package electionapp;


public class Admin extends Candidate {
    
    protected String adminID;
    // Update Constructor to match Candidate
    public Admin(String name, String password, String adminID){
        super(name, password);
        this.adminID=adminID;
    }
    public Admin(){
        this("","","");
    }

    // We need to get rid of the variable above and just set them in the action button performed to add a new candidate
    public String getAdminID() {
        return adminID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    @Override
    public String printDetails(){
        return super.printDetails()+"\n Admin ID: "+adminID;
    }
}
