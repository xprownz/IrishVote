/*
ElectionApp.java

This the App class of the Election App

Election App for Object Oriented Programming Project 
HCCE2&BHSC2 Class 2018-2019
By Cian Harris, Aaron Reilly and Alejandro Diaz
 */
package electionapp;


public class ElectionApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        MainGUI myGUI=new MainGUI();
        myGUI.setVisible(true);
        
    }
    
}
