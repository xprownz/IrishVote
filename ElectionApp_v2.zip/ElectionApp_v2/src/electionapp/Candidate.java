/*
Candidate.java

Superclass

Election App for Object Oriented Programming Project 
HCCE2&BHSC2 Class 2018-2019
By Cian Harris, Aaron Reilly and Alejandro Diaz


 */
package electionapp;


public class Candidate {
    protected String name;
    protected String password;
    
    public Candidate(){
        this("","");
    }
     public Candidate(String name, String password){
         this.name=name;
         this.password=password;
     }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String printDetails(){
        return "User Name: "+name+"\n Password: "+password;
    }

}
